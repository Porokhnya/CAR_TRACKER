/*
заголовочный файл подключаемой библиотеки
декодирования/кодирования посылок трекеров
ВНИМАНИЕ: после изменения этого файла необходимо перекомпилировать все подключаемые библиотеки
*/
#ifndef __CODER__
#define __CODER__

#include <stdio.h>  /* snprintf, FILENAME_MAX */
#include <stdlib.h> /* malloc */
#include <string.h> /* memset */
#include <errno.h>  /* errno */
#include <time.h>		/* localtime */
#include <math.h>		/* fabs */
#include <syslog.h>

#ifndef MILE
	#define MILE 1.852	// коэфф мили/километры
#endif
#ifndef SIZE_TRACKER_FIELD
	#define SIZE_TRACKER_FIELD 16
#endif
#ifndef BAD_OBJ
	#define BAD_OBJ (-1)
#endif
#ifndef SOCKET_BUF_SIZE
	#define SOCKET_BUF_SIZE (4096)
#endif
#ifndef MAX_RECORDS
	#define MAX_RECORDS (30)
#endif

// декодированные данные
typedef struct {
	char imei[SIZE_TRACKER_FIELD];
	char tracker[SIZE_TRACKER_FIELD];	// модель трекера
	char hard[SIZE_TRACKER_FIELD];	// версия железа
	char soft[SIZE_TRACKER_FIELD];	// версия прошивки
	char clon;
	char clat;
	time_t data;
	unsigned int status;  // статус устройства, битовое поле
	unsigned int recnum;
	unsigned int time;
	unsigned int valid;
	unsigned int satellites;
	unsigned int curs;
	int height;
	unsigned int hdop;
	unsigned int outputs;	// статус выходов, битовое поле
	unsigned int inputs;	// статус входов, битовое поле
	int ainputs[8];
	int fuel[2];
	int temperature;
	int zaj;							// зажигание
	int alarm;						// тревога
	double lon;
	double lat;
	double speed;
	double vbort;
	double vbatt;
	double probeg;
} ST_RECORD;
// sizeof(ST_RECORD)=224

/* структура, возвращаемая функцией terminal_decode
если в процессе декодирования произошла ошибка, поле error должно быть > 0
если декодированных данных нет,
	поле count должно быть равно 0
если ответ устройству не требуется,
	поле size должно быть равно 0
*/
typedef struct {
	int error;	// > 0 if decode/encode error occur
	int size;	// size of field answer
	int count;	// number of decoded records in array
	char answer[SOCKET_BUF_SIZE];	// answer to gps/glonass terminal
	ST_RECORD records[MAX_RECORDS];	// array of the decoded records
	ST_RECORD lastpoint;	// last navigation data
} ST_ANSWER;
// sizeof(ST_ANSWER)=11056

#endif
