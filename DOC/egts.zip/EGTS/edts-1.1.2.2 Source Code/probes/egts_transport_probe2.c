/*****************************************************************************/
/*                                                                           */
/* File: egts_transport_probe1.c                                             */
/*                                                                           */
/* System: ERA GLONASS terminal communication protocol reference impl.       */
/*                                                                           */
/* Component Name: Tests                                                     */
/*                                                                           */
/* Status: Version 1.1                                                       */
/*                                                                           */
/* Language: C                                                               */
/*                                                                           */
/* (c) Copyright JSC �Navigation-information systems�, 2011                  */
/*                                                                           */
/* Address:                                                                  */
/*     24, Mishina Str., bld.1                                               */
/*     Moscow, Russia                                                        */
/*                                                                           */
/* Description: main() function for autotest.                                */
/*                                                                           */
/* Additional information: -                                                 */
/*                                                                           */
/* Functions:                                                                */
/*                                                                           */
/*****************************************************************************/


#include "egts_config.h"
#include "egts.h"
#include "egts_impl.h"

#include "egts_probe.h"
#include "../transport/egts_dump.h"

/*****************************************************************************
*
*/

#include <stdarg.h>
#include <stdlib.h>

/*****************************************************************************
*
*/

egts_state_t  estate_rx;
egts_state_t  estate_tx;

FILE *fl_dump = NULL;
FILE *fl_out  = NULL;
FILE *fl_in  = NULL;

/*****************************************************************************
*
*/

int  estate_tx_buffer_loop( void* ctx , void* pbuf , u32 sz ) 
{
  u8 *puc = (u8*)pbuf;

  if ( fl_out && sz && pbuf ) 
  {
    if ( (size_t)sz != fwrite( (const void *)pbuf, (size_t)1, (size_t)sz, fl_out ) ) {
      fprintf( fl_dump , "output write error" );
    }
  }

  for ( ; sz; sz-- )
    egts_rx_byte( (egts_state_t*)ctx, *puc++ );

  return 0;
}

int  estate_tx_file( void* ctx , void* pbuf , u32 sz ) 
{
  (void)ctx;
  
  if ( fl_out && sz && pbuf ) 
  {
    if ( (size_t)sz != fwrite( (const void *)pbuf, (size_t)1, (size_t)sz, fl_out ) ) {
      fprintf( fl_dump , "output write error" );
    }
  }

  return 0;
}

void  estate_tx_error( void* actx , u16 PID , u8 err , const char* dgb_str )
{
  (void)actx;
  (void)PID;
  (void)err;

  if ( dgb_str )
    fprintf( fl_dump , "tx error: %s\n" , dgb_str );
}

void  estate_rx_error( void* actx , u16 PID , u8 err , const char* dgb_str )
{
  (void)actx;
  (void)PID;
  (void)err;

  if ( dgb_str )
    fprintf( fl_dump ,"rx error: %s\n" , dgb_str );
}

void printf_dump( void* ctx , const char* fmt , ... ) 
{
  va_list v;

  (void)ctx;
  va_start(v,fmt);
  vfprintf( fl_dump , fmt , v );
}

void egts_probe_printf( const char* fmt , ... )
{
  va_list v;
  va_start(v,fmt);
  vfprintf( fl_dump , fmt , v );
}

int  rx_packet_probe_and_dump( void* ctx , 
  egts_header_t*            pheader , 
  u8                        signed_up ,
  egts_responce_header_t*   presponce ,
  egts_record_t*            precords ,
  u16                       nrecords ,
  u16                       FDL )
{

  estate_dump_packet( 
    pheader ,
    signed_up ,
    presponce ,
    precords ,
    nrecords ,
    ctx ,
    printf_dump
  );

  return
    estate_rx_packet_probe( ctx , 
      pheader , 
      signed_up ,
      presponce ,
      precords ,
      nrecords ,
      FDL );

}

int  rx_packet_dump( void* ctx , 
  egts_header_t*            pheader , 
  u8                        signed_up ,
  egts_responce_header_t*   presponce ,
  egts_record_t*            precords ,
  u16                       nrecords ,
  u16                       FDL )
{
  (void)FDL;

  estate_dump_packet( 
      pheader ,
      signed_up ,
      presponce ,
      precords ,
      nrecords ,
      ctx ,
      printf_dump
    );
  return 0;
}
u8    temp_buf[ 65536 ];

/*****************************************************************************
*
*/

egts_probe_ctx_t       probes_ctx;

/*****************************************************************************
*
*/

int return_usage()
{
  printf("Usage: probe2 [-d <dump_file>][-x <out_file>] -n <test_num>\n");
  printf("    or probe2 -N\n");
  printf("    or probe2 [-d <dump_file>][-x <out_file>] -i <in_file>\n");
  return 1;
}

int return_test_count()
{
  int n = 0;
  const tf_probe_send*      pfn_probe_send;

  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    n++;
  }
  printf( "%u" , n );
  return 0;
}

/*****************************************************************************
*
*/


int main(int argc, char* argv[])
{

  egts_profile_t def_profile;
  u8             def_priority;
  egts_route_t   test_route;
  u16            PID;
  const tf_probe_send*      pfn_probe_send;
  egts_responce_header_t    responce;

  char** pc, cs;
  char*  pc_dump_file = NULL;
  char*  pc_out_file  = NULL;
  char*  pc_in_file   = NULL;
  u8     uc;

  int    n_test = -1;


  pc = argv;
  cs = 0;
  for ( --argc; argc; argc-- )
  {

    pc++;

    switch ( **pc )
    {

    case '-':

      switch ( *(++(*pc)) )
      {
      case 'd':
        cs = 'd';
        if ( 0U != *(++(*pc)) ) {
          return return_test_count();
        }
        break;

      case 'x':
        cs = 'x';
        if ( 0U != *(++(*pc)) ) {
          return return_test_count();
        }
        break;

      case 'i':
        cs = 'i';
        if ( 0U != *(++(*pc)) ) {
          return return_test_count();
        }
        break;

      case 'N':
        if ( 0U != *(++(*pc)) ) {
          return return_test_count();
        }
        return return_test_count();

      case 'n':
        cs = 'n';
        if ( 0U != *(++(*pc)) ) {
          return return_test_count();
        }
        break;

      default:
        return return_usage();

      }
      break;

    default:

      switch( cs )
      {
      case 'd':
        if ( pc_dump_file ) {
          return return_usage();
        }
        pc_dump_file = *pc;
        cs = 0;
        break;

      case 'x':
        if ( pc_out_file ) {
          return return_usage();
        }
        pc_out_file = *pc;
        cs = 0;
        break;

      case 'i':
        if ( pc_in_file ) {
          return return_usage();
        }
        pc_in_file = *pc;
        cs = 0;
        break;

      case 'n':
        if ( -1 != n_test ){
          return return_usage();
        }
        n_test = atoi( *pc );
        if ( 0 == n_test ){
          return return_usage();
        }
        cs = 0;
        break;

      default:
        return return_usage();
      }

    }

  }
  
  if ( !pc_in_file && -1 == n_test ){
    return return_usage();
  }

  /*
  *
  */

  if ( pc_dump_file ) {
    fl_dump = fopen( (const char *)pc_dump_file, "wb" );
    if ( !fl_dump ) {
      fprintf( stderr , "failed to open dump file %s" , pc_dump_file );
      return 1;
    }
    fseek( fl_dump , 0 , SEEK_SET );
  } else {
    fl_dump = stdout;
  }

  if ( pc_out_file ) {
    fl_out = fopen( (const char *)pc_out_file, "wb" );
    if ( !fl_out ) {
      fprintf( stderr , "failed to open output file %s" , pc_out_file );
      return 1;
    }
    fseek( fl_out , 0 , SEEK_SET );
  }

  if ( pc_in_file )  {
    fl_in = fopen( (const char *)pc_in_file, "rb" );
    if ( !fl_in ) {
      fprintf( stderr , "failed to open input file %s" , pc_in_file );
      return 1;
    }
  }

  /*
  *
  */

  def_profile.CMP  = 0;
  def_profile.ENA  = EGTS_DATA_ENA_NONE;
  def_profile.HE   = EGTS_HEADER_ENCODING_NONE;
  def_profile.SGN  = 0;
  def_profile.SKID = 0;

  def_priority     = 0;

  test_route.PRA   = 1;
  test_route.RCA   = 1;
  test_route.TTL   = 1;

  probes_ctx.precords    = NULL;
  probes_ctx.nrecords    = 0;
  probes_ctx.nerr        = 0;
  probes_ctx.last_result = 0;

  PID = 1;
  responce.PR   = EGTS_PC_OK;
  responce.RPID = 1000;

  estate_rx.cur_rx_packet = (egts_packet_state_t*)malloc( sizeof(egts_packet_state_t) );

  estate_tx.cur_tx_packet = (egts_packet_state_t*)malloc( sizeof(egts_packet_state_t) );



  /*
  *
  */

  if ( fl_in )
  {

    egts_init( &estate_rx, NULL, 
      NULL , 
      rx_packet_dump , 
      estate_tx_error ,
      estate_rx_error
      );

    while ( 1 == fread( &uc, 1 , 1 , fl_in ) )
    {
      egts_rx_byte( &estate_rx, uc );
    }


  }
  else
  {


    egts_init( &estate_rx, &probes_ctx , 
      NULL , 
      rx_packet_probe_and_dump ,
      estate_tx_error ,
      estate_rx_error
      );

    egts_init( &estate_tx, &estate_rx , 
      estate_tx_buffer_loop ,
      NULL ,
      estate_tx_error ,
      estate_rx_error
      );



    for ( pfn_probe_send = egts_probes_vector;
          *pfn_probe_send;
          pfn_probe_send++ )
    {
      if ( 0 ==  --n_test ) {
        (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, NULL , temp_buf , 65535 );
        break;
      }
      
    }

  }


  free( estate_rx.cur_rx_packet );
  free( estate_tx.cur_tx_packet );

  /*
  *
  */

  if ( fl_in ) {
    fclose( fl_in );
  }

  if ( fl_dump && 
       fl_dump != stdout )
  {
    fflush( fl_dump );
    fclose( fl_dump );
  }
  if ( fl_out ) {
    fclose( fl_out );
  }

  /*
  *
  */

  if ( probes_ctx.nerr )
    return 1;
  return 0;
}

/*****************************************************************************
*
*/


