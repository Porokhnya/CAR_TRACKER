/*****************************************************************************/
/*                                                                           */
/* File: egts_transport_probe1.c                                             */
/*                                                                           */
/* System: ERA GLONASS terminal communication protocol reference impl.       */
/*                                                                           */
/* Component Name: Tests                                                     */
/*                                                                           */
/* Status: Version 1.1                                                       */
/*                                                                           */
/* Language: C                                                               */
/*                                                                           */
/* (c) Copyright JSC �Navigation-information systems�, 2011                  */
/*                                                                           */
/* Address:                                                                  */
/*     24, Mishina Str., bld.1                                               */
/*     Moscow, Russia                                                        */
/*                                                                           */
/* Description: main() function for autotest.                                */
/*                                                                           */
/* Additional information: -                                                 */
/*                                                                           */
/* Functions:                                                                */
/*                                                                           */
/*****************************************************************************/


#include "egts_config.h"
#include "egts.h"
#include "egts_impl.h"

#include "egts_probe.h"

/*****************************************************************************
*
*/

#include <stdarg.h>
#include <stdlib.h>

/*****************************************************************************
*
*/

egts_state_t  estate_rx;
egts_state_t  estate_tx;

int  estate_tx_buffer_loop( void* ctx , void* pbuf , u32 sz ) 
{
  u8 *puc = (u8*)pbuf;

  for ( ; sz; sz-- )
    egts_rx_byte( (egts_state_t*)ctx, *puc++ );

  return 0;
}

void  estate_tx_error( void* actx , u16 PID , u8 err , const char* dgb_str )
{
  (void)actx;
  (void)PID;
  (void)err;

  if ( dgb_str )
    printf( "tx error: %s\n" , dgb_str );
}

void  estate_rx_error( void* actx , u16 PID , u8 err , const char* dgb_str )
{
  (void)actx;
  (void)PID;
  (void)err;

  if ( dgb_str )
    printf( "rx error: %s\n" , dgb_str );
}

void printf_dump( void* ctx , const char* fmt , ... ) 
{
  va_list v;

  (void)ctx;
  va_start(v,fmt);
  vprintf( fmt , v );
}

void egts_probe_printf( const char* fmt , ... )
{
  va_list v;
  va_start(v,fmt);
  vprintf( fmt , v );
}

u8    temp_buf[ 65536 ];

/*****************************************************************************
*
*/

egts_probe_ctx_t       probes_ctx;

/*****************************************************************************
*
*/


int main(int argc, char* argv[])
{

  egts_profile_t def_profile;
  u8             def_priority;
  egts_route_t   test_route;
  u16            PID;
  const tf_probe_send*      pfn_probe_send;
  egts_responce_header_t    responce;

  (void)argc;
  (void)argv;

  def_profile.CMP  = 0;
  def_profile.ENA  = EGTS_DATA_ENA_NONE;
  def_profile.HE   = EGTS_HEADER_ENCODING_NONE;
  def_profile.SGN  = 0;
  def_profile.SKID = 0;

  def_priority     = 0;

  test_route.PRA   = 1;
  test_route.RCA   = 1;
  test_route.TTL   = 1;

  probes_ctx.precords    = NULL;
  probes_ctx.nrecords    = 0;
  probes_ctx.nerr        = 0;
  probes_ctx.last_result = 0;

  estate_rx.cur_rx_packet = (egts_packet_state_t*)malloc( sizeof(egts_packet_state_t) );

  egts_init( &estate_rx, &probes_ctx , 
    NULL , 
    estate_rx_packet_probe ,
    estate_tx_error ,
    estate_rx_error
    );

  estate_tx.cur_tx_packet = (egts_packet_state_t*)malloc( sizeof(egts_packet_state_t) );

  egts_init( &estate_tx, &estate_rx , 
    estate_tx_buffer_loop ,
    NULL ,
    estate_tx_error ,
    estate_rx_error
    );

  /*
  *
  */


  PID = 1;
  responce.PR   = EGTS_PC_OK;
  responce.RPID = 1000;

  printf("\n");
  printf("Header encoding - NONE\n");
  printf("Data encoding - NONE\n");
  printf("Compression - NONE\n");
  printf("Sign-up - NONE\n");
  printf("Responce - NONE\n");
  printf("\n");
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, NULL , temp_buf , 65535 );
    PID++;
  }


  printf("\n");
  printf("Header encoding - NONE\n");
  printf("Data encoding - NONE\n");
  printf("Compression - NONE\n");
  printf("Sign-up - NONE\n");
  printf("Responce - YES\n");
  printf("\n");
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, &responce , temp_buf , 65535 );
    PID++;
  }

  def_profile.HE   = EGTS_HEADER_ENCODING_DBG;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - NONE\n");
  printf("Compression - NONE\n");
  printf("Sign-up - NONE\n");
  printf("Responce - NONE\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, NULL , temp_buf , 65535 );
    PID++;
  }

  def_profile.HE   = EGTS_HEADER_ENCODING_DBG;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - NONE\n");
  printf("Compression - NONE\n");
  printf("Sign-up - NONE\n");
  printf("Responce - YES\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, &responce , temp_buf , 65535 );
    PID++;
  }


  def_profile.HE   = EGTS_HEADER_ENCODING_DBG;
  def_profile.ENA  = EGTS_DATA_ENA_DBG;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - DBG\n");
  printf("Compression - NONE\n");
  printf("Sign-up - NONE\n");
  printf("Responce - NONE\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, NULL , temp_buf , 65535 );
    PID++;
  }

  def_profile.ENA  = EGTS_DATA_ENA_DBG;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - DBG\n");
  printf("Compression - NONE\n");
  printf("Sign-up - NONE\n");
  printf("Responce - YES\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, &responce ,  temp_buf , 65535 );
    PID++;
  }


  def_profile.CMP  = 1;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - DBG\n");
  printf("Compression - DBG\n");
  printf("Sign-up - NONE\n");
  printf("Responce - NONE\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, NULL , temp_buf , 65535 );
    PID++;
  }

  def_profile.CMP  = 1;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - DBG\n");
  printf("Compression - DBG\n");
  printf("Sign-up - NONE\n");
  printf("Responce - YES\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, &responce , temp_buf , 65535 );
    PID++;
  }

  def_profile.ENA  = EGTS_DATA_ENA_NONE;
  def_profile.CMP  = 0;
  def_profile.SGN  = 1;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - NONE\n");
  printf("Compression - NONE\n");
  printf("Sign-up - DBG\n");
  printf("Responce - NONE\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, NULL , temp_buf , 65535 );
    PID++;
  }

  def_profile.CMP  = 0;
  def_profile.SGN  = 1;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - DBG\n");
  printf("Compression - NONE\n");
  printf("Sign-up - DBG\n");
  printf("Responce - NONE\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, NULL , temp_buf , 65535 );
    PID++;
  }

  def_profile.SGN  = 1;
  printf("\n");
  printf("Header encoding - DBG\n");
  printf("Data encoding - DBG\n");
  printf("Compression - DBG\n");
  printf("Sign-up - DBG\n");
  printf("Responce - NONE\n");
  printf("\n");
  PID = 1;
  for ( pfn_probe_send = egts_probes_vector;
        *pfn_probe_send;
        pfn_probe_send++ )
  {
    (*pfn_probe_send)( &estate_tx , &def_profile , def_priority , NULL , PID, NULL , temp_buf , 65535 );
    PID++;
  }


  free( estate_rx.cur_rx_packet );
  free( estate_tx.cur_tx_packet );

  printf("\n");
  printf("erorr count: %u\n" , probes_ctx.nerr );
  if ( probes_ctx.nerr )
  {
    printf("autotests FAILED\n");
    return 1;
  }

  printf("autotests PASSED\n");
	return 0;
}

/*****************************************************************************
*
*/


