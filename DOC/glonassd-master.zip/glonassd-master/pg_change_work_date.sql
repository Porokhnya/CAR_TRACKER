/* смена рабочей даты:     новая дата, кол-во месяцев хранения данных */
select gps.pchangeworkdata(current_date, 6);